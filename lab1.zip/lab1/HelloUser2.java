public class HelloUser2{
	public static void main(String[] args){
		System.out.println("Hello! This program was done by Harshul Srivastava and Sathya Gadhiraju");
}
}

